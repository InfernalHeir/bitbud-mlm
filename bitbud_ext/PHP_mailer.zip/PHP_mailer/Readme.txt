Paste this three files in your Root Directory

~ Happy Coding ~